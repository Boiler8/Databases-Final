package App.Application.Controllers;

import App.Infrastructure.PetRepository;
import App.Infrastructure.ShelterRepository;
import Domain.Shelter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController()
@RequestMapping("/Shelter")
public class ShelterController {

    private final ShelterRepository shelterRepository;

    public ShelterController(@Autowired JdbcTemplate databaseConnection){
        this.shelterRepository = new ShelterRepository(databaseConnection);
    }
    @GetMapping("")
    public List<Shelter> getAllShelters(){
        return this.shelterRepository.get();
    }
}
