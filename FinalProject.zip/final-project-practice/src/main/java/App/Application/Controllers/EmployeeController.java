package App.Application.Controllers;

import App.Infrastructure.EmployeeRepository;
import Domain.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Employee")
public class EmployeeController {

    private final EmployeeRepository employeeRepository;

    public EmployeeController(@Autowired JdbcTemplate databaseConnection) {
        this.employeeRepository = new EmployeeRepository(databaseConnection);
    }

    @GetMapping("")
    public List<Employee> getAllEmployees() {
        return this.employeeRepository.get();
    }

    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable String id) throws Exception {
        return this.employeeRepository.get(id);
    }

    @PostMapping("")
    public void addEmployee(@RequestBody Employee employee) {
        this.employeeRepository.create(employee);
    }

    @PutMapping("/{id}")
    public void updateEmployee(@PathVariable String id, @RequestBody Employee employee) {
        this.employeeRepository.update(id, employee);
    }

    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable String id) {
        this.employeeRepository.delete(id);
    }
}
