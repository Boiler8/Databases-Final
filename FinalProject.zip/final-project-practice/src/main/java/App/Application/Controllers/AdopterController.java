package App.Application.Controllers;

import App.Infrastructure.AdopterRepository;
import App.Infrastructure.PetRepository;
import App.Infrastructure.ShelterRepository;
import Domain.Adopter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController()
@RequestMapping("/Adopter")
public class AdopterController {

    private final AdopterRepository adopterRepository;

    public AdopterController(@Autowired JdbcTemplate databaseConnection){
        this.adopterRepository = new AdopterRepository(databaseConnection);
    }
    @GetMapping("")
    public List<Adopter> getAllAdopter(){
        return this.adopterRepository.get();
    }
}
