package App.Application.Controllers;

import App.Infrastructure.StaffRepository;
import Domain.Staff;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Staff")
public class StaffController {

    private final StaffRepository staffRepository;

    public StaffController(@Autowired JdbcTemplate databaseConnection) {
        this.staffRepository = new StaffRepository(databaseConnection);
    }

    @GetMapping("")
    public List<Staff> getAllStaff() {
        return this.staffRepository.get();
    }

    @GetMapping("/{id}")
    public Staff getStaffById(@PathVariable String id) throws Exception {
        return this.staffRepository.get(id);
    }

    @GetMapping("/filter")
    public List<Staff> getStaffByAvailability(@RequestParam String availability) {
        return this.staffRepository.getByAvailability(availability);
    }

    @PostMapping("")
    public void addStaff(@RequestBody Staff staff) {
        this.staffRepository.create(staff);
    }

    @PutMapping("/{id}")
    public void updateStaff(@PathVariable String id, @RequestBody Staff staff) {
        this.staffRepository.update(id, staff);
    }

    @DeleteMapping("/{id}")
    public void deleteStaff(@PathVariable String id) {
        this.staffRepository.delete(id);
    }
}
