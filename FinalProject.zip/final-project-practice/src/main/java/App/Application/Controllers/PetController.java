package App.Application.Controllers;

import App.Infrastructure.PetRepository;
import Domain.Pet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Pet")
public class PetController {

    private final PetRepository petRepository;

    public PetController(@Autowired JdbcTemplate databaseConnection) {
        this.petRepository = new PetRepository(databaseConnection);
    }

    @GetMapping("")
    public List<Pet> getAllPets() {
        return this.petRepository.get();
    }

    @GetMapping("/{id}")
    public Pet getPetById(@PathVariable String id) throws Exception {
        return this.petRepository.get(id);
    }

    @PostMapping("")
    public void addPet(@RequestBody Pet pet) {
        this.petRepository.create(pet);
    }

    @PutMapping("/{id}")
    public void updatePet(@PathVariable String id, @RequestBody Pet pet) {
        this.petRepository.update(id, pet);
    }

    @DeleteMapping("/{id}")
    public void deletePet(@PathVariable String id) {
        this.petRepository.delete(id);
    }
}
