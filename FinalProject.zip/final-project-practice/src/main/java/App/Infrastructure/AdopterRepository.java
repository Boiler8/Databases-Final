package App.Infrastructure;
import java.beans.BeanProperty;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import Domain.Adopter;
import org.springframework.jdbc.core.JdbcTemplate;

public class AdopterRepository extends BaseRepository<Adopter>{
    public AdopterRepository(JdbcTemplate databaseConnection){
        super(databaseConnection);
    }
    @Override
    public Adopter get(String id) throws Exception {
        return null;
    }

    @Override
    public List<Adopter> get() {
        String sql = "SELECT * FROM ADOPTER;";
        List<Adopter> adopters = this.getDatabaseConnection().query(sql, BeanPropertyRowMapper.newInstance(Adopter.class));
        return adopters;
    }

    @Override
    public void create(Adopter adopter) {

    }

    @Override
    public void delete(String id) {

    }

    @Override
    public void update(String id, Adopter adopter) {

    }
}
