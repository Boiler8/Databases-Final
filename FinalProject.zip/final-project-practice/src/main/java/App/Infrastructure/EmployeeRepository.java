package App.Infrastructure;

import Domain.Employee;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.List;

public class EmployeeRepository extends BaseRepository<Employee> {

    public EmployeeRepository(JdbcTemplate databaseConnection) {
        super(databaseConnection);
    }

    @Override
    public Employee get(String id) throws Exception {
        String sql = "SELECT * FROM EMPLOYEE WHERE staff_id = ?;";
        return this.getDatabaseConnection().queryForObject(sql, new Object[]{id}, BeanPropertyRowMapper.newInstance(Employee.class));
    }

    @Override
    public List<Employee> get() {
        String sql = "SELECT * FROM EMPLOYEE;";
        return this.getDatabaseConnection().query(sql, BeanPropertyRowMapper.newInstance(Employee.class));
    }

    @Override
    public void create(Employee employee) {
        String sql = "INSERT INTO EMPLOYEE (staff_id, start_date, max_hours, role) " +
                "VALUES (?, ?, ?, ?);";
        this.getDatabaseConnection().update(sql, employee.getStaff_id(), employee.getStart_date(),
                employee.getMax_hours(), employee.getRole());
    }

    @Override
    public void delete(String id) {
        String sql = "DELETE FROM EMPLOYEE WHERE staff_id = ?;";
        this.getDatabaseConnection().update(sql, id);
    }

    @Override
    public void update(String id, Employee employee) {
        String sql = "UPDATE EMPLOYEE SET start_date = ?, max_hours = ?, role = ? WHERE staff_id = ?;";
        this.getDatabaseConnection().update(sql, employee.getStart_date(), employee.getMax_hours(),
                employee.getRole(), id);
    }
}
