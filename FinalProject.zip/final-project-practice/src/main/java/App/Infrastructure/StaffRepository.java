package App.Infrastructure;

import Domain.Pet;
import Domain.Staff;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.List;

public class StaffRepository extends BaseRepository<Staff> {
    public StaffRepository(JdbcTemplate databaseConnection) {
        super(databaseConnection);
    }

    @Override
    public Staff get(String id) throws Exception {
        String sql = "SELECT * FROM STAFF WHERE staff_id = ?;";
        return this.getDatabaseConnection().queryForObject(sql, new Object[]{id}, BeanPropertyRowMapper.newInstance(Staff.class));
    }

    @Override
    public List<Staff> get() {
        String sql = "SELECT * FROM STAFF;";
        return this.getDatabaseConnection().query(sql, BeanPropertyRowMapper.newInstance(Staff.class));
    }

    @Override
    public void create(Staff staff) {
        String sql = "INSERT INTO STAFF (staff_id, name, phone, email, availability) " +
                "VALUES (?, ?, ?, ?, ?);";
        this.getDatabaseConnection().update(sql, staff.getStaff_id(), staff.getName(), staff.getPhone(),
                staff.getEmail(), staff.getAvailability());
    }

    @Override
    public void delete(String id) {
        String sql = "DELETE FROM STAFF WHERE staff_id = ?;";
        this.getDatabaseConnection().update(sql, id);
    }

    @Override
    public void update(String id, Staff staff) {
        String sql = "UPDATE STAFF SET name = ?, phone = ?, email = ?, availability = ? WHERE staff_id = ?;";
        this.getDatabaseConnection().update(sql, staff.getName(), staff.getPhone(), staff.getEmail(),
                staff.getAvailability(), id);
    }
    public List<Staff> getByAvailability(String availability) {
        String sql = "SELECT * FROM STAFF WHERE availability LIKE ?;";
        return this.getDatabaseConnection().query(sql, new Object[]{"%" + availability + "%"},
                BeanPropertyRowMapper.newInstance(Staff.class));
    }

}
