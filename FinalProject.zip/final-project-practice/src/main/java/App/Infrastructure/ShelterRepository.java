package App.Infrastructure;
import java.beans.BeanProperty;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import Domain.Shelter;
import org.springframework.jdbc.core.JdbcTemplate;

public class ShelterRepository extends BaseRepository<Shelter>{
    public ShelterRepository(JdbcTemplate databaseConnection){
        super(databaseConnection);
    }
    @Override
    public Shelter get(String id) throws Exception {
        return null;
    }

    @Override
    public List<Shelter> get() {
        String sql = "SELECT * FROM SHELTER;";
        List<Shelter> shelters = this.getDatabaseConnection().query(sql, BeanPropertyRowMapper.newInstance(Shelter.class));
        return shelters;
    }

    @Override
    public void create(Shelter shelter) {

    }

    @Override
    public void delete(String id) {

    }

    @Override
    public void update(String id, Shelter shelter) {

    }
}
