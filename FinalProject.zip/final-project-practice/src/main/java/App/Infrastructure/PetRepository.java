package App.Infrastructure;

import Domain.Pet;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.List;

public class PetRepository extends BaseRepository<Pet> {
    public PetRepository(JdbcTemplate databaseConnection) {
        super(databaseConnection);
    }

    @Override
    public Pet get(String id) throws Exception {
        String sql = "SELECT * FROM PET WHERE pet_id = ?;";
        return this.getDatabaseConnection().queryForObject(sql, new Object[]{id}, BeanPropertyRowMapper.newInstance(Pet.class));
    }

    @Override
    public List<Pet> get() {
        String sql = "SELECT * FROM PET;";
        return this.getDatabaseConnection().query(sql, BeanPropertyRowMapper.newInstance(Pet.class));
    }

    @Override
    public void create(Pet pet) {
        String sql = "INSERT INTO PET (pet_id, name, species, breed, age, sex, adopted, claws, adoption_fee, description) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        this.getDatabaseConnection().update(sql, pet.getPet_id(), pet.getName(), pet.getSpecies(), pet.getBreed(), pet.getAge(), pet.getSex(),
                pet.getAdopted(), pet.getClaws(), pet.getAdoption_fee(), pet.getDescription());
    }

    @Override
    public void delete(String id) {
        String sql = "DELETE FROM PET WHERE pet_id = ?;";
        this.getDatabaseConnection().update(sql, id);
    }

    @Override
    public void update(String id, Pet pet) {
        String sql = "UPDATE PET SET name = ?, species = ?, breed = ?, age = ?, sex = ?, adopted = ?, claws = ?, " +
                "adoption_fee = ?, description = ? WHERE pet_id = ?;";
        this.getDatabaseConnection().update(sql, pet.getName(), pet.getSpecies(), pet.getBreed(), pet.getAge(),
                pet.getSex(), pet.getAdopted(), pet.getClaws(), pet.getAdoption_fee(), pet.getDescription(), id);
    }
}
