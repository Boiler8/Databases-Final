package Domain;

public class Staff {
    private int staff_id;
    private String name;
    private String phone;
    private String email;
    private String availability;

    public int getStaff_id(){
        return staff_id;
    }
    public void setStaff_id(int staff_id){
        this.staff_id = staff_id;
    }

    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getPhone(){
        return phone;
    }
    public void setPhone(String phone){
        this.phone = phone;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getAvailability(){
        return availability;
    }
    public void setAvailability(String availability){
        this.availability = availability;
    }
}
