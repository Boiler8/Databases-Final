package Domain;

public class Employee {

    private int staff_id;
    private String start_date;
    private int max_hours;
    private String role;

    public int getStaff_id(){
        return staff_id;
    }
    public void setStaff_id(int staff_id){
        this.staff_id = staff_id;
    }

    public String getStart_date(){
        return start_date;
    }
    public void setStart_date(String start_date){
        this.start_date = start_date;
    }

    public int getMax_hours(){
        return max_hours;
    }
    public void setMax_hours(int max_hours){
        this.max_hours = max_hours;
    }

    public String getRole(){
        return role;
    }
    public void setRole(String role){
        this.role = role;
    }
}
