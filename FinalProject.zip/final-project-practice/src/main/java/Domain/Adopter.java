package Domain;

public class Adopter {
    private int adopter_id;
    private String name;
    private String address;
    private String email;
    private String phone_number;

    public int getAdopter_id(){
        return adopter_id;
    }
    public void setAdopter_id(int adopter_id){
        this.adopter_id = adopter_id;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getAddress(){
        return address;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getPhone_number(){
        return phone_number;
    }
    public void setPhone_number(String phone_number){
        this.phone_number = phone_number;
    }
}
