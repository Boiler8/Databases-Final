package Domain;

public class Shelter {
    private int shelter_id;
    private String shelter_name;
    private String address;
    private int capacity;

    public int getShelter_id(){
        return shelter_id;
    }
    public void setShelter_id(int shelter_id){
        this.shelter_id = shelter_id;
    }
    public String getShelter_name(){
        return shelter_name;
    }
    public void setShelter_name(String shelter_name){
        this.shelter_name = shelter_name;
    }
    public String getAddress(){
        return address;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public int getCapacity(){
        return capacity;
    }
    public void setCapacity(int capacity){
        this.capacity = capacity;
    }
}
