package Domain;

public class Pet {
    private int pet_id;
    private String name;
    private String species;
    private String breed;
    private int age;
    private char sex;
    private boolean adopted;
    private boolean claws;
    private float adoption_fee;
    private String description;

    public int getPet_id(){
        return pet_id;
    }
    public void setPet_id(int pet_id){
        this.pet_id = pet_id;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getSpecies(){
        return species;
    }
    public void setSpecies(String species){
        this.species = species;
    }
    public String getBreed(){
        return breed;
    }
    public void setBreed(String breed){
        this.breed = breed;
    }

    public int getAge(){
        return age;
    }
    public void setAge(int age){
        this.age = age;
    }
    public char getSex(){
        return sex;
    }
    public void setSex(char sex){
        this.sex = sex;
    }
    public boolean getAdopted(){
        return adopted;
    }
    public void setAdopted(boolean adopted){
        this.adopted = adopted;
    }
    public boolean getClaws(){
        return claws;
    }
    public void setClaws(boolean claws){
        this.claws= claws;
    }
    public float getAdoption_fee(){
        return adoption_fee;
    }
    public void setAdoption_fee(float adoption_fee){
        this.adoption_fee = adoption_fee;
    }
    public String getDescription(){
        return description;
    }
    public void setDescription(String description){
        this.description = description;
    }
}
